# Financial Formulas Reference (v1.0.1)

This document provides the mandatory mathematical definitions for all financial metrics evaluated by the **ANSHora — Business Intelligence Analyst** skill.

---

## 1. Gross Margin: Weighted vs. Unweighted

### The Golden Rule
> **MANDATORY**: Overall gross margin MUST ALWAYS be calculated as total profit divided by total revenue over valid rows.  
> **FORBIDDEN**: Never calculate overall gross margin by taking the unweighted average of row-level margins.

### Mathematical Formulation
$$\text{Overall Gross Margin } \% = \frac{\sum_{i \in \text{paired}} \text{Profit}_i}{\sum_{i \in \text{paired}} \text{Revenue}_i} \times 100$$
Where $\text{paired}$ represents all rows where both Revenue and Profit (or COGS) are present, valid, and finite.

### Zero and Negative Denominator Guardrails
- If $\sum_{i \in \text{paired}} \text{Revenue}_i \le 0$, the weighted margin percentage is mathematically undefined or economically meaningless. It MUST be reported as `null` / `None`, accompanied by an explicit disclosure:
  *"Net revenue is zero or negative; weighted margin cannot be reliably computed."*

### Why Unweighted Averages Are Mathematically Invalid
Consider a business with two transactions:
- **Transaction A (Small order)**: Revenue = $100.00, Cost = $10.00, Profit = $90.00. Row Margin = **90.0%**.
- **Transaction B (Large bulk order)**: Revenue = $10,000.00, Cost = $9,000.00, Profit = $1,000.00. Row Margin = **10.0%**.

- **Incorrect (Unweighted Mean)**:
  $$\frac{90.0\% + 10.0\%}{2} = 50.0\% \quad \text{(Grossly Overstated Hallucination)}$$
- **Correct (Weighted ANSHora Standard)**:
  $$\text{Total Revenue} = \$10,100.00, \quad \text{Total Profit} = \$1,090.00$$
  $$\text{True Gross Margin} = \frac{\$1,090.00}{\$10,100.00} \times 100 = \mathbf{10.79\%}$$

The unweighted average skews results wildly toward low-volume, high-margin outliers. The ANSHora skill strictly enforces weighted margins.

---

## 2. Gross Profit & Paired-Row Integrity

### Consistently Paired Rows
Gross profit and margin can only be computed over rows that possess both revenue and cost (or direct profit):
- If a row has valid revenue but null cost, that revenue is included in top-level revenue, but excluded from gross profit derivation.
- When unpaired rows occur, the analysis must disclose:
  *"X rows with revenue lacked cost data and were excluded from profit/margin calculations."*

### Derived Cost & Profit Calculations
- When Revenue and Cost exist: $\text{Gross Profit} = \text{Revenue} - \text{Cost}$
- When Revenue and Profit exist, but Cost is omitted: $\text{Derived Cost} = \text{Revenue} - \text{Profit}$
- Label clearly: *"Cost derived as (Revenue − Profit)"* or *"Profit derived as (Revenue − Cost)"*.

---

## 3. Duplicate Handling & Dual Reporting

When exact duplicate rows are detected:
- **Exact Duplicate Count & Percentage**: Counted and reported non-destructively.
- **Duplicate Revenue Exposure**:
  $$\text{Duplicate Revenue Exposure} = \sum_{r \in \text{duplicates}} \text{Revenue}_r$$
- **Dual Reporting**: Report headline KPIs both across all rows (inclusive) and with duplicates isolated (deduplicated baseline). Never silently discard duplicate rows.

---

## 4. Average Order Value (AOV)

### Unique Order Level (When Order ID is Available)
$$\text{AOV} = \frac{\sum \text{Revenue}}{\text{Total Unique Orders}}$$
- If transactions are logged line-by-line across multiple items, aggregate line-level revenue by `Order_ID` first.
- Report AOV based on unique orders, and disclose the line-item average separately.

### Transaction Line Level (When Order ID is Absent)
$$\text{Line-Item Average} = \frac{\sum \text{Revenue}}{\text{Total Rows}}$$
- Explicitly label as: *"Transaction-line average (Order ID column absent)"*.

---

## 5. Return Rate & Exposure

$$\text{Return Rate } \% = \frac{\text{Count of Returned Orders}}{\text{Total Orders}} \times 100$$
$$\text{Return Value Exposure} = \sum_{i \in \text{returned}} \text{Revenue}_i$$

---

## 6. Discount Rate & Revenue Leakage

$$\text{Average Discount } \% = \frac{\sum \text{Discount Percentage}}{\text{Count of Valid Rows}} \times 100$$
$$\text{Discount Leakage Amount} = \sum \left( \frac{\text{Net Revenue}}{1 - \text{Discount Rate}} - \text{Net Revenue} \right)$$
When only net revenue and discount percentage are recorded:
$$\text{Gross List Price} = \frac{\text{Revenue}}{1 - \text{Discount \%}}$$

---

## 7. Period-over-Period Growth

$$\text{Growth } \% = \frac{\text{Revenue}_{t} - \text{Revenue}_{t-1}}{\text{Revenue}_{t-1}} \times 100$$
- **Zero Denominator Protection**: If $\text{Revenue}_{t-1} = 0$, growth is mathematically undefined. Report as: `"N/A (base period is zero)"` or disclose the absolute dollar increase.
- **Negative Base Protection**: If base period revenue was negative, disclose both the direction and absolute shift rather than a distorted percentage.

---

## 8. Margin Gap (Leakage Opportunity)

To quantify money at stake when a segment underperforms company benchmark:
$$\text{Margin Gap} = \text{Benchmark Margin } \% - \text{Segment Margin } \%$$
$$\text{Profit Leakage Amount} = \text{Segment Revenue} \times \left(\frac{\text{Margin Gap}}{100}\right)$$
Example: A $100,000 segment operating at 25% margin when company average is 30% has a 5% margin gap, representing **$5,000.00 in profit leakage**.
