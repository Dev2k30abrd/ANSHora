#!/usr/bin/env python3
"""
ANSHora — Business Intelligence Analyst: Deterministic CSV Analysis Helper (v1.0.1).
Pure Python standard library script. Read-only. Emits structured JSON to stdout.
"""

import argparse
import csv
import json
import math
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

REVENUE_HINTS = ("revenue", "sales", "total_amount", "order_total", "turnover", "gross_sales")
COST_HINTS = ("cost", "cogs", "expenses", "unit_cost", "total_cost", "expense", "purchase_price")
PROFIT_HINTS = ("profit", "gross_profit", "net_profit", "margin_amount", "operating_profit")
DISCOUNT_HINTS = ("discount", "discount_amount", "discount_pct", "discount_rate")
RETURN_HINTS = ("return", "returns", "returned", "refund", "refunds", "is_returned")
DATE_HINTS = ("date", "order_date", "transaction_date", "invoice_date", "created_at")
ORDER_ID_HINTS = ("order_id", "order_no", "order_number", "invoice_no", "invoice_id", "transaction_id")
ID_HINTS = ("id", "order_id", "customer_id", "transaction_id", "uuid", "sku", "code", "zip", "phone")


def clean_number(val):
    if val is None:
        return None
    s = str(val).strip()
    if not s or s.lower() in ("null", "none", "nan", "n/a", "na", "-", ""):
        return None
    cleaned = re.sub(r"[,\s₹$€£%]", "", s)
    try:
        f = float(cleaned)
        return f if math.isfinite(f) else None
    except ValueError:
        return None


def parse_date(val):
    if not val:
        return None
    s = str(val).strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y",
                "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m", "%b %Y", "%B %Y"):
        try:
            return datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            continue
    m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            pass
    return None


def detect_delimiter(sample):
    if not sample:
        return ","
    try:
        return csv.Sniffer().sniff(sample[:4096], delimiters=",;\t|").delimiter
    except Exception:
        c = {d: sample.count(d) for d in (",", "\t", ";", "|")}
        b = max(c, key=c.get)
        return b if c[b] > 0 else ","


def calculate_quantiles(sorted_f):
    n = len(sorted_f)
    if n == 0:
        return {"min": None, "q1": None, "median": None, "q3": None, "max": None, "iqr": None}
    def q(p):
        k = (n - 1) * p
        f, c = math.floor(k), math.ceil(k)
        return sorted_f[int(k)] if f == c else sorted_f[int(f)] * (c - k) + sorted_f[int(c)] * (k - f)
    q1, med, q3 = q(0.25), q(0.50), q(0.75)
    return {"min": round(sorted_f[0], 4), "q1": round(q1, 4), "median": round(med, 4), "q3": round(q3, 4), "max": round(sorted_f[-1], 4), "iqr": round(q3 - q1, 4)}


def find_column_match(headers, hints, explicit=None):
    if explicit:
        for h in headers:
            if h.strip().lower() == explicit.strip().lower():
                return h
        return None
    norm = {re.sub(r"[^a-z0-9]", "", h.lower()): h for h in headers}
    for hint in hints:
        ch = re.sub(r"[^a-z0-9]", "", hint.lower())
        if ch in norm:
            return norm[ch]
    for hint in hints:
        ch = re.sub(r"[^a-z0-9]", "", hint.lower())
        for nh, orig in norm.items():
            if ch in nh:
                return orig
    return None


def compute_kpis_for_rows(rows, rev_c, cst_c, prf_c, ord_c):
    has_r, has_p, has_c = rev_c is not None, prf_c is not None, cst_c is not None
    rev_nums = [clean_number(r.get(rev_c)) for r in rows] if has_r else []
    v_revs = [rv for rv in rev_nums if rv is not None]
    tot_rev = sum(v_revs) if v_revs else (0.0 if has_r and rows else None)

    p_rev, p_prof, p_cost = [], [], []
    unp_r, unp_c = 0, 0
    for r in rows:
        rv = clean_number(r.get(rev_c)) if has_r else None
        pv = clean_number(r.get(prf_c)) if has_p else None
        cv = clean_number(r.get(cst_c)) if has_c else None
        if has_r and rv is not None:
            if has_p and pv is not None:
                p_rev.append(rv); p_prof.append(pv); p_cost.append(rv - pv)
            elif has_c and cv is not None:
                p_rev.append(rv); p_cost.append(cv); p_prof.append(rv - cv)
            elif has_p or has_c:
                unp_r += 1
        elif (has_p and pv is not None) or (has_c and cv is not None):
            unp_c += 1

    tot_p, tot_c, w_margin, p_src, c_src = None, None, None, None, None
    if has_p and p_prof:
        tot_p, p_src = round(sum(p_prof), 2), f"direct from column '{prf_c}'"
        s_prev = sum(p_rev)
        w_margin = round((sum(p_prof) / s_prev) * 100, 2) if s_prev > 0 else None
        if not has_c:
            tot_c, c_src = round(s_prev - sum(p_prof), 2), "derived (revenue - profit)"
        else:
            c_vals = [clean_number(r.get(cst_c)) for r in rows]
            tot_c, c_src = round(sum(v for v in c_vals if v is not None), 2), f"direct from column '{cst_c}'"
    elif has_c and p_cost:
        tot_c, c_src = round(sum(p_cost), 2), f"direct from column '{cst_c}'"
        s_prev = sum(p_rev)
        der_p = s_prev - sum(p_cost)
        tot_p, p_src = round(der_p, 2), "derived (revenue - cost)"
        w_margin = round((der_p / s_prev) * 100, 2) if s_prev > 0 else None

    u_orders, aov_type = None, "line_item_average"
    line_avg = round(tot_rev / max(len(v_revs), 1), 2) if tot_rev is not None else None
    aov = line_avg
    if ord_c and has_r:
        ord_totals = defaultdict(float)
        for r in rows:
            oid = r.get(ord_c)
            if oid:
                rv = clean_number(r.get(rev_c))
                if rv is not None:
                    ord_totals[oid] += rv
        if ord_totals:
            u_orders = len(ord_totals)
            aov = round(sum(ord_totals.values()) / max(u_orders, 1), 2)
            aov_type = "unique_orders"

    return {
        "row_count": len(rows), "unique_orders_count": u_orders,
        "total_revenue": round(tot_rev, 2) if tot_rev is not None else None,
        "total_cost": tot_c, "total_profit": tot_p, "weighted_margin_pct": w_margin,
        "average_order_value": aov, "aov_type": aov_type, "line_item_average": line_avg,
        "cost_source": c_src, "profit_source": p_src, "paired_valid_rows": len(p_rev),
        "unpaired_revenue_rows": unp_r, "unpaired_cost_rows": unp_c,
        "zero_revenue_rows": sum(1 for v in v_revs if v == 0),
        "negative_revenue_rows": sum(1 for v in v_revs if v < 0),
    }


def analyze(file_path, revenue_col=None, cost_col=None, profit_col=None, date_col=None, order_id_col=None, dimensions=None, top_n=10):
    path = Path(file_path)
    if not path.exists() or not path.is_file():
        return {"error": f"File not found or not regular file: {file_path}", "status": "failed"}

    try:
        with open(path, "rb") as bf:
            sample = bf.read(16384)
            if not sample:
                return {"status": "success", "file_name": path.name, "row_count": 0, "column_count": 0, "columns": [],
                        "message": "File is empty (0 bytes).", "data_quality": {"empty": True, "health_score": 0.0, "health_status": "Empty Dataset"}}
    except Exception as e:
        return {"error": f"Could not read file: {e}", "status": "failed"}

    has_bom = sample.startswith(b"\xef\xbb\xbf")
    enc = "utf-8-sig" if has_bom else "utf-8"
    try:
        text_sample = sample.decode(enc, errors="replace")
    except Exception as e:
        return {"error": f"Encoding error: {e}", "status": "failed"}

    delim = detect_delimiter(text_sample)
    rows, seen, dup_rows, u_rows = [], set(), [], []
    with open(path, "r", encoding=enc, errors="replace") as f:
        reader = csv.reader(f, delimiter=delim)
        try:
            first = next(reader, None)
        except Exception as e:
            return {"error": f"Header error: {e}", "status": "failed"}
        if first is None:
            return {"status": "success", "file_name": path.name, "row_count": 0, "column_count": 0, "columns": [],
                    "message": "File contains no rows.", "data_quality": {"empty": True, "health_score": 0.0, "health_status": "Empty Dataset"}}
        headers = [str(h).strip() for h in first if str(h).strip()]
        if not headers:
            return {"error": "CSV contains no valid non-empty headers.", "status": "failed"}
        ncols = len(headers)
        for raw in reader:
            padded = raw + [""] * (ncols - len(raw)) if len(raw) < ncols else raw[:ncols]
            rk = tuple(padded)
            rd = {headers[i]: padded[i].strip() for i in range(ncols)}
            if rk in seen:
                dup_rows.append(rd)
            else:
                seen.add(rk)
                u_rows.append(rd)
            rows.append(rd)

    rcnt = len(rows)
    miss_cnt, miss_pct = {}, {}
    num_cols, date_cols, cat_cols = {}, {}, {}
    type_contam = {}

    for h in headers:
        vals = [r[h] for r in rows]
        ecnt = sum(1 for v in vals if not v or v.lower() in ("null", "none", "nan", "n/a", "na", "-"))
        miss_cnt[h] = ecnt
        miss_pct[h] = round((ecnt / max(rcnt, 1)) * 100, 2)
        nums = [clean_number(v) for v in vals]
        v_nums = [n for n in nums if n is not None]
        n_ratio = len(v_nums) / max(len(vals) - ecnt, 1)
        dates = [parse_date(v) for v in vals]
        v_dates = [d for d in dates if d is not None]
        d_ratio = len(v_dates) / max(len(vals) - ecnt, 1)
        is_id = any(hint in h.lower() for hint in ID_HINTS)
        type_contam[h] = sum(1 for v, n in zip(vals, nums) if n is None and v and v.lower() not in ("null", "none", "nan", "n/a", "na", "-"))
        if d_ratio >= 0.75 and not is_id:
            date_cols[h] = v_dates
        elif (n_ratio >= 0.65 or (revenue_col and h.lower() == revenue_col.lower())) and not is_id:
            num_cols[h] = v_nums
        else:
            cat_cols[h] = vals

    rev_c = find_column_match(headers, REVENUE_HINTS, revenue_col)
    cst_c = find_column_match(headers, COST_HINTS, cost_col)
    prf_c = find_column_match(headers, PROFIT_HINTS, profit_col)
    dt_c = find_column_match(headers, DATE_HINTS, date_col)
    ord_c = find_column_match(headers, ORDER_ID_HINTS, order_id_col)
    disc_c = find_column_match(headers, DISCOUNT_HINTS)
    ret_c = find_column_match(headers, RETURN_HINTS)

    if prf_c and rev_c and prf_c == rev_c:
        prf_c = None
    if cst_c and rev_c and cst_c == rev_c:
        cst_c = None

    num_sums = {}
    tot_outliers = 0
    for col, nums in num_cols.items():
        if not nums:
            continue
        n_c = len(nums)
        s_nums = sorted(nums)
        q = calculate_quantiles(s_nums)
        iqr = q["iqr"]
        if n_c < 4:
            lb, ub, ocnt = None, None, 0
        elif iqr > 0:
            lb, ub = q["q1"] - 1.5 * iqr, q["q3"] + 1.5 * iqr
            ocnt = sum(1 for n in nums if (n < lb or n > ub))
        else:
            mu = sum(nums) / n_c
            var = sum((x - mu) ** 2 for x in nums) / max(n_c - 1, 1)
            sd = math.sqrt(var)
            if sd == 0:
                lb, ub, ocnt = s_nums[0], s_nums[-1], 0
            else:
                lb, ub = mu - 2.5 * sd, mu + 2.5 * sd
                ocnt = sum(1 for n in nums if (n < lb or n > ub))
        tot_outliers += ocnt
        num_sums[col] = {
            "valid_count": n_c, "missing_count": miss_cnt[col], "sum": round(sum(nums), 4),
            "mean": round(sum(nums) / n_c, 4), "quantiles": q, "outliers_count": ocnt,
            "outlier_bounds": {"lower": round(lb, 4) if lb is not None else None, "upper": round(ub, 4) if ub is not None else None}
        }

    avg_m = sum(miss_pct.values()) / max(len(miss_pct), 1)
    dup_cnt = len(dup_rows)
    dup_pct = (dup_cnt / max(rcnt, 1)) * 100
    out_pct = (tot_outliers / max(rcnt * max(len(num_sums), 1), 1)) * 100
    contam_cells = sum(type_contam[c] for c in num_cols)
    contam_pct = (contam_cells / max(rcnt * max(len(num_cols), 1), 1)) * 100

    p_miss, p_dup, p_out, p_typ = min(40.0, round(avg_m * 1.5, 2)), min(30.0, round(dup_pct * 2.0, 2)), min(20.0, round(out_pct * 1.0, 2)), min(10.0, round(contam_pct * 1.0, 2))
    score = max(0.0, min(100.0, round(100.0 - (p_miss + p_dup + p_out + p_typ), 1)))
    status = "High Reliability" if score >= 85.0 else "Acceptable (Caveats Disclosed)" if score >= 70.0 else "Needs Review (High Risk of Skewed Findings)"

    kpi_all = compute_kpis_for_rows(rows, rev_c, cst_c, prf_c, ord_c)
    kpi_dedup = compute_kpis_for_rows(u_rows, rev_c, cst_c, prf_c, ord_c) if dup_cnt > 0 else kpi_all
    d_rev = sum(clean_number(r.get(rev_c)) or 0.0 for r in dup_rows) if rev_c else 0.0
    d_cst = sum(clean_number(r.get(cst_c)) or 0.0 for r in dup_rows) if cst_c else 0.0
    d_prf = d_rev - d_cst if (cst_c and rev_c) else (sum(clean_number(r.get(prf_c)) or 0.0 for r in dup_rows) if prf_c else 0.0)

    fin_kpis = {
        "revenue_column": rev_c, "cost_column": cst_c, "profit_column": prf_c,
        "date_column": dt_c, "order_id_column": ord_c, "discount_column": disc_c, "return_column": ret_c,
        "all_rows": kpi_all, "deduplicated": kpi_dedup,
        "duplicate_exposure": {"exact_duplicate_rows": dup_cnt, "duplicate_revenue": round(d_rev, 2), "duplicate_cost": round(d_cst, 2), "duplicate_profit": round(d_prf, 2)},
        "total_revenue": kpi_all["total_revenue"], "total_cost": kpi_all["total_cost"], "total_profit": kpi_all["total_profit"],
        "weighted_margin_pct": kpi_all["weighted_margin_pct"], "average_order_value": kpi_all["average_order_value"],
        "aov_type": kpi_all["aov_type"], "line_item_average": kpi_all["line_item_average"],
        "cost_source": kpi_all["cost_source"], "profit_source": kpi_all["profit_source"],
        "paired_valid_rows": kpi_all["paired_valid_rows"], "zero_revenue_rows": kpi_all["zero_revenue_rows"], "negative_revenue_rows": kpi_all["negative_revenue_rows"]
    }

    t_dims = []
    if dimensions:
        for d in dimensions:
            for h in headers:
                if h.strip().lower() == d.strip().lower():
                    t_dims.append(h)
    else:
        for h, vals in cat_cols.items():
            dc = len(set(v for v in vals if v))
            if 2 <= dc <= 25 and not any(w in h.lower() for w in ID_HINTS):
                t_dims.append(h)
                if len(t_dims) >= 3:
                    break

    seg_bd = {}
    tot_v_rev = fin_kpis["total_revenue"] or 1.0
    for dim in t_dims:
        counts = Counter(r[dim] for r in rows if r[dim])
        d_items = []
        for cat in [c for c, _ in counts.most_common(top_n)]:
            c_rows = [r for r in rows if r[dim] == cat]
            cnt = len(c_rows)
            cr = sum(clean_number(r[rev_c]) or 0 for r in c_rows) if rev_c else 0
            item = {"segment_value": cat, "row_count": cnt, "row_share_pct": round((cnt / max(rcnt, 1)) * 100, 2)}
            if rev_c:
                item["revenue"] = round(cr, 2)
                item["revenue_share_pct"] = round((cr / max(tot_v_rev, 1e-9)) * 100, 2)
            if prf_c:
                cp = sum(clean_number(r[prf_c]) or 0 for r in c_rows)
                item["profit"] = round(cp, 2)
                if cr > 0:
                    item["margin_pct"] = round((cp / cr) * 100, 2)
            elif cst_c and rev_c:
                cc = sum(clean_number(r[cst_c]) or 0 for r in c_rows)
                cp = cr - cc
                item["cost"], item["profit"] = round(cc, 2), round(cp, 2)
                if cr > 0:
                    item["margin_pct"] = round((cp / cr) * 100, 2)
            d_items.append(item)
        seg_bd[dim] = d_items

    t_series = []
    if dt_c:
        p_grp = defaultdict(list)
        for r in rows:
            dto = parse_date(r.get(dt_c))
            if dto:
                p_grp[dto.strftime("%Y-%m")].append(r)
        prev_r = None
        for p in sorted(p_grp.keys()):
            pr_rows = p_grp[p]
            pr = sum(clean_number(r[rev_c]) or 0 for r in pr_rows) if rev_c else None
            p_grw = round(((pr - prev_r) / prev_r) * 100, 2) if (prev_r and prev_r > 0 and pr is not None) else None
            ent = {"period": p, "rows": len(pr_rows)}
            if pr is not None:
                ent["revenue"] = round(pr, 2)
                ent["growth_vs_previous_period_pct"] = p_grw
            if prf_c:
                pp = sum(clean_number(r[prf_c]) or 0 for r in pr_rows)
                ent["profit"] = round(pp, 2)
                if pr and pr > 0:
                    ent["margin_pct"] = round((pp / pr) * 100, 2)
            elif cst_c and rev_c:
                pc = sum(clean_number(r[cst_c]) or 0 for r in pr_rows)
                pp = pr - pc
                ent["cost"], ent["profit"] = round(pc, 2), round(pp, 2)
                if pr and pr > 0:
                    ent["margin_pct"] = round((pp / pr) * 100, 2)
            t_series.append(ent)
            if pr is not None:
                prev_r = pr

    notices = [
        f"Dataset contains {rcnt:,} rows and {ncols} columns.",
        "Overall weighted margin = (Total Profit ÷ Total Revenue × 100); row margins are never averaged.",
        f"Exact duplicate rows ({dup_cnt}) identified for audit transparency and not silently removed.",
    ]
    if dup_cnt > 0 and rev_c:
        notices.append(f"Duplicate revenue exposure: ${d_rev:,.2f}. All-rows and deduplicated KPIs provided.")
    if kpi_all["unpaired_revenue_rows"] > 0:
        notices.append(f"{kpi_all['unpaired_revenue_rows']} rows with revenue lacked cost data and were excluded from profit/margin calculations.")

    return {
        "status": "success", "file_name": path.name, "delimiter": delim, "has_utf8_bom": has_bom,
        "row_count": rcnt, "total_raw_rows": rcnt, "column_count": ncols, "columns": headers,
        "data_quality": {
            "health_score": score, "health_status": status,
            "penalties": {
                "missing_values": {"percentage": round(avg_m, 2), "penalty": p_miss, "cap": 40.0},
                "exact_duplicates": {"percentage": round(dup_pct, 2), "penalty": p_dup, "cap": 30.0},
                "statistical_outliers": {"percentage": round(out_pct, 2), "penalty": p_out, "cap": 20.0},
                "type_contamination": {"percentage": round(contam_pct, 2), "penalty": p_typ, "cap": 10.0, "contaminated_cells": contam_cells},
            },
            "exact_duplicate_rows": dup_cnt, "duplicate_percentage": round(dup_pct, 2),
            "duplicate_revenue_exposure": round(d_rev, 2),
            "missing_values_by_column": miss_cnt, "missing_percentages": miss_pct,
            "total_outliers_detected": tot_outliers,
        },
        "capabilities": {
            "revenue_available": rev_c is not None, "cost_available": bool(cst_c or (rev_c and prf_c)),
            "profit_available": bool(prf_c or (rev_c and cst_c)), "date_timeline_available": bool(dt_c and len(t_series) >= 2),
            "order_id_available": ord_c is not None, "discount_available": disc_c is not None,
            "returns_available": ret_c is not None, "customer_segments_available": len(seg_bd) > 0,
        },
        "financial_kpis": fin_kpis, "numeric_summaries": num_sums,
        "segment_breakdowns": seg_bd, "time_series": t_series, "analytical_notices": notices,
    }


def main():
    p = argparse.ArgumentParser(description="CSV Analysis Helper (v1.0.1)")
    p.add_argument("file_path")
    p.add_argument("--revenue", dest="revenue_col")
    p.add_argument("--cost", dest="cost_col")
    p.add_argument("--profit", dest="profit_col")
    p.add_argument("--date", dest="date_col")
    p.add_argument("--order-id", dest="order_id_col")
    p.add_argument("--dimensions")
    p.add_argument("--top", dest="top_n", type=int, default=10)
    a = p.parse_args()
    d = [x.strip() for x in a.dimensions.split(",")] if a.dimensions else None
    res = analyze(a.file_path, a.revenue_col, a.cost_col, a.profit_col, a.date_col, a.order_id_col, d, a.top_n)
    print(json.dumps(res, indent=2))
    return 0 if res.get("status") == "success" else 1


if __name__ == "__main__":
    sys.exit(main())
