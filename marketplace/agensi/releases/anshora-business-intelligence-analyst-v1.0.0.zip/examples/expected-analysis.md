# Expected Analysis Reference: Sample Business Data

This reference document demonstrates the exact analytical standard, structure, and grounding produced by an agent running the **ANSHora — Business Intelligence Analyst** skill on [`sample-business-data.csv`](./sample-business-data.csv).

---

## 1. Dataset Intake & Capabilities Map

- **File Analysed**: `sample-business-data.csv`
- **Total Records**: 25 raw records, 10 columns.
- **Grain**: Transactional order-level records across 6 months (Jan 2025 – Jun 2025).
- **Mapped Columns**:
  - Revenue: `Revenue`
  - Cost / COGS: `Cost`
  - Profit: Derived (`Revenue - Cost`)
  - Date: `Date`
  - Dimensions: `Product_Category`, `Customer_Segment`, `Region`
  - Commercial Attributes: `Discount_Pct`, `Returned`
- **Capability Boundaries**:
  - ✅ Revenue, COGS, and derived Gross Profit available.
  - ✅ Channel/Region/Category/Segment comparisons supported.
  - ✅ Discount rate and Returns tracking supported.
  - ❌ Customer identifiers (e.g. lifetime value, cohort retention) NOT available in dataset.
  - ❌ Operational overheads / marketing spend NOT present; profit refers strictly to Gross Profit.

---

## 2. Data Health & Trust Audit

- **Data Health Score**: **91.0 / 100**
- **Completeness**: 0 missing values across all 10 columns (100% complete).
- **Exact Duplicate Rows**: **1 duplicate row identified (4.0%)**
  - Duplicate Row: `ORD-1024, 2025-06-27, Corporate, Furniture, West, $21,000.00, Cost: $15,200.00`
  - *Audit Note*: Disclosed in findings. Duplicate represents $21,000.00 in revenue exposure.
- **Outliers Detected**:
  - `Quantity`: 1 upper outlier identified (`Quantity = 25` on order `ORD-1018`, upper IQR bound = 20.5). Flagged for order batch review, not deleted.
- **Data Integrity**: Clean numeric formats; valid ISO dates throughout.

---

## 3. Executive Financial Summary (Headline KPIs)

*All figures calculated deterministically via Python standard library:*

| Financial Metric | Deterministic Value | Calculation Method / Source |
|---|---|---|
| **Total Revenue** | **$276,000.00** | Sum of `Revenue` column across all 25 rows |
| **Total Cost (COGS)** | **$189,300.00** | Sum of `Cost` column |
| **Total Gross Profit** | **$86,700.00** | Derived: `Total Revenue - Total Cost` |
| **Overall Gross Margin** | **31.41%** | **Weighted**: `Total Profit ÷ Total Revenue × 100` |
| **Average Order Value (AOV)** | **$11,040.00** | `Total Revenue ÷ Total Orders (25)` |
| **Return Rate** | **8.00%** | 2 returned orders out of 25 total orders |
| **Average Discount Given** | **6.20%** | Mean of `Discount_Pct` |

> ⚠️ **Methodological Notice**:
> The overall gross margin is strictly **31.41%** (weighted). Averaging row-level margins yields an incorrect figure of 31.79%. ANSHora rules forbid row-level margin averaging.

---

## 4. Segment & Category Deep-Dive

### By Product Category
| Product Category | Orders | Revenue | Rev Share | Gross Profit | Category Margin |
|---|:---:|:---:|:---:|:---:|:---:|
| **Electronics** | 11 | $165,800.00 | 60.07% | $53,300.00 | **32.15%** |
| **Furniture** | 8 | $95,800.00 | 34.71% | $26,500.00 | **27.66%** |
| **Office Supplies** | 6 | $14,400.00 | 5.22% | $6,900.00 | **47.92%** |

- **Key Finding**: Electronics drives 60.07% of company revenue with healthy 32.15% margin. Furniture underperforms on margin (27.66%, a 3.75 percentage-point margin gap vs company average), representing $3,592.50 in margin leakage. Office Supplies yields high margins (47.92%) but low volume (5.22% share).

### By Customer Segment
| Customer Segment | Orders | Revenue | Rev Share | Gross Profit | Segment Margin |
|---|:---:|:---:|:---:|:---:|:---:|
| **Corporate** | 10 | $177,400.00 | 64.28% | $55,700.00 | **31.40%** |
| **Consumer** | 8 | $49,450.00 | 17.92% | $15,000.00 | **30.33%** |
| **Small Business** | 7 | $49,150.00 | 17.81% | $16,000.00 | **32.55%** |

- **Key Finding**: Corporate customers constitute the core engine, generating $177,400.00 (64.28% of total revenue) at an average order size of $17,740.00.

---

## 5. Monthly Trend Analysis

| Month | Orders | Revenue | MoM Growth | Gross Profit | Monthly Margin |
|---|:---:|:---:|:---:|:---:|:---:|
| **2025-01** | 3 | $18,200.00 | — | $6,000.00 | 32.97% |
| **2025-02** | 4 | $48,400.00 | +165.93% | $15,400.00 | 31.82% |
| **2025-03** | 4 | $25,100.00 | -48.14% | $7,800.00 | 31.08% |
| **2025-04** | 4 | $62,650.00 | +149.60% | $19,800.00 | 31.60% |
| **2025-05** | 5 | $33,100.00 | -47.17% | $10,500.00 | 31.72% |
| **2025-06** | 5 | $88,550.00 | +167.52% | $27,200.00 | 30.72% |

- **Seasonality Pattern**: Alternating bi-monthly procurement surges (February, April, June) driven by large Corporate bulk orders.

---

## 6. What-If Scenario Simulation

**Scenario**: *What if Furniture discounts are capped, improving Furniture gross margin from 27.66% to the 31.41% company average?*

- **Baseline Furniture Revenue**: $95,800.00
- **Baseline Furniture Profit**: $26,500.00 (27.66%)
- **Simulated Furniture Profit (at 31.41%)**: $30,090.78
- **Projected Profit Impact**: **+$3,590.78 additional gross profit** with zero volume change.
- *Caveat*: Simulated estimate assumes price elasticity does not reduce order volume.

---

## 7. Actionable Recommendations & Decision Log Entry

1. **Investigate Furniture Margin Leakage (Priority 1)**:
   - *Observation*: Furniture margin lags at 27.66% with highest average discount (up to 15% on orders `ORD-1005` and `ORD-1024`).
   - *Action*: Review vendor supply agreements for Furniture and cap sales rep discretionary discounts at 8%.
   - *Owner*: Head of Merchandising / Sales Director.
   - *Review Date*: End of Q3 2025.
   - *Success Metric*: Furniture margin exceeding 30.0%.

2. **Deduplicate Transaction Log (Priority 2)**:
   - *Observation*: Order `ORD-1024` is logged twice on 2025-06-27.
   - *Action*: Confirm with ERP/billing whether this was a duplicate charge or a logging artifact. If duplicate entry, true revenue is $255,000.00.
