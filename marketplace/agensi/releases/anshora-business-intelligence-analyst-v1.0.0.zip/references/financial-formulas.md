# Financial Formulas Reference

This document provides the mandatory mathematical definitions for all financial metrics evaluated by the **ANSHora — Business Intelligence Analyst** skill.

---

## 1. Gross Margin: Weighted vs. Unweighted

### The Golden Rule
> **MANDATORY**: Overall gross margin MUST ALWAYS be calculated as total profit divided by total revenue over valid rows.  
> **FORBIDDEN**: Never calculate overall gross margin by taking the unweighted average of row-level margins.

### Mathematical Formulation
$$\text{Overall Gross Margin } \% = \frac{\sum_{i \in \text{valid}} \text{Profit}_i}{\sum_{i \in \text{valid}} \text{Revenue}_i} \times 100$$
Where $\text{valid}$ represents all rows where both Revenue and Profit (or COGS) are present and finite.

### Why Unweighted Averages Are Mathematically Invalid
Consider a business with two transactions:
- **Transaction A (Small order)**: Revenue = $100.00, Cost = $10.00, Profit = $90.00. Row Margin = **90.0%**.
- **Transaction B (Large bulk order)**: Revenue = $10,000.00, Cost = $9,000.00, Profit = $1,000.00. Row Margin = **10.0%**.

- **Incorrect (Unweighted Mean)**:
  $$\frac{90.0\% + 10.0\%}{2} = 50.0\% \quad \text{(Grossly Overstated Hallucination)}$$
- **Correct (Weighted ANSHora Standard)**:
  $$\text{Total Revenue} = \$10,100.00, \quad \text{Total Profit} = \$1,090.00$$
  $$\text{True Gross Margin} = \frac{\$1,090.00}{\$10,100.00} \times 100 = \mathbf{10.79\%}$$

The unweighted average skews results wildly toward low-volume, high-margin outliers. The ANSHora skill strictly enforces weighted margins.

---

## 2. Gross Profit & Derived Cost Formulas

### Direct Profit Calculation
When both Revenue and Cost columns exist:
$$\text{Gross Profit} = \text{Revenue} - \text{Cost}$$

### Derived Cost Calculation
When Revenue and Profit columns exist, but Cost is omitted:
$$\text{Derived Cost} = \text{Revenue} - \text{Profit}$$
*Reporting Disclosure*: When cost is derived, the report must label it: *"Cost derived as (Revenue − Profit)"*.

---

## 3. Average Order Value (AOV)

$$\text{AOV} = \frac{\sum \text{Revenue}}{\text{Total Valid Order Count}}$$
- If transactions are logged line-by-line by item, group by `Order_ID` first before computing order-level AOV.
- Disclose whether AOV represents per-line average or per-unique-order average.

---

## 4. Return Rate

$$\text{Return Rate } \% = \frac{\text{Count of Returned Orders}}{\text{Total Orders}} \times 100$$
$$\text{Return Value Exposure} = \sum_{i \in \text{returned}} \text{Revenue}_i$$

---

## 5. Discount Rate & Revenue Leakage

$$\text{Average Discount } \% = \frac{\sum \text{Discount Percentage}}{\text{Count of Discounted Rows}} \times 100$$
$$\text{Discount Leakage Amount} = \sum \left( \frac{\text{Net Revenue}}{1 - \text{Discount Rate}} - \text{Net Revenue} \right)$$
When only net revenue and discount percentage are recorded:
$$\text{Gross List Price} = \frac{\text{Revenue}}{1 - \text{Discount \%}}$$

---

## 6. Period-over-Period Growth

$$\text{Growth } \% = \frac{\text{Revenue}_{t} - \text{Revenue}_{t-1}}{\text{Revenue}_{t-1}} \times 100$$
- **Zero Denominator Protection**: If $\text{Revenue}_{t-1} = 0$, growth is mathematically undefined. Report as: `"N/A (base period is zero)"` or disclose the absolute dollar increase.
- **Negative Base Protection**: If base period revenue was negative, disclose both the direction and absolute shift rather than a distorted percentage.

---

## 7. Margin Gap (Leakage Opportunity)

To quantify money at stake when a segment underperforms company benchmark:
$$\text{Margin Gap} = \text{Benchmark Margin } \% - \text{Segment Margin } \%$$
$$\text{Profit Leakage Amount} = \text{Segment Revenue} \times \left(\frac{\text{Margin Gap}}{100}\right)$$
Example: A $100,000 segment operating at 25% margin when company average is 30% has a 5% margin gap, representing **$5,000.00 in profit leakage**.
