# Data Quality & Trust Rules

High-conviction decision-making requires honest data auditing. This reference outlines how data quality, anomalies, and trust metrics must be evaluated and reported under the **ANSHora — Business Intelligence Analyst** framework.

---

## 1. Non-Destructive Ingestion Rule

> **MANDATORY**: Never silently clean, mutate, drop, or overwrite source data.  
> All anomalies, missing entries, duplicates, and outliers must be counted, quantified, disclosed, and preserved in the audit log.

When performing analyses:
- Disclose raw row counts vs. valid rows used in calculations.
- If duplicate rows exist, report results both with and without duplicates if the variance is material.
- Never impute fabricated numbers for missing financial fields.

---

## 2. The Four Pillars of the Data Health Score (0–100)

The Data Health Score quantifies dataset trustworthiness on a 0 to 100 scale based on four deterministic penalties:

$$\text{Health Score} = 100.0 - P_{\text{missing}} - P_{\text{duplicates}} - P_{\text{outliers}} - P_{\text{types}}$$

| Penalty Component | Metric Formula | Maximum Deduction |
|---|---|:---:|
| **$P_{\text{missing}}$** | $\text{Overall Missing Value } \% \times 1.5$ | 40 points |
| **$P_{\text{duplicates}}$** | $\text{Exact Duplicate Row } \% \times 2.0$ | 30 points |
| **$P_{\text{outliers}}$** | $\text{Outlier Ratio across Numerics } \% \times 1.0$ | 20 points |
| **$P_{\text{types}}$** | String contamination in numeric columns | 10 points |

A score above 85 indicates high reliability. Scores between 70 and 85 require disclosure of caveats. Scores below 70 indicate high risk of skewed findings.

---

## 3. Handling Specific Anomalies

### A. Missing Values
- Report missing value percentage per column.
- For financial metrics (Revenue, Cost, Profit), exclude rows with missing values from margin denominators and state:  
  *"X rows lack revenue or cost values and were excluded from margin calculations."*

### B. Exact Duplicate Rows
- An exact duplicate is defined as a row where every single column value matches an existing row identically.
- If exact duplicates are found:
  1. Report the exact count and duplicate percentage.
  2. Compute the total revenue exposure tied to duplicate entries:
     $$\text{Duplicate Revenue Exposure} = \sum_{r \in \text{duplicates}} \text{Revenue}_r$$
  3. Present the headline metrics and clearly state whether duplicates are included or isolated.

### C. Statistical Outlier Detection (Tukey's IQR Fence)
- For every numeric column with at least 5 values:
  $$\text{IQR} = Q_3 - Q_1$$
  $$\text{Lower Bound} = Q_1 - (1.5 \times \text{IQR})$$
  $$\text{Upper Bound} = Q_3 + (1.5 \times \text{IQR})$$
- Flag values falling outside $[\text{Lower Bound}, \text{Upper Bound}]$.
- **Crucial Rule**: Do NOT automatically delete outliers. In e-commerce and B2B sales, high outliers frequently represent genuine VIP enterprise orders. Flag them as high-leverage observations.

### D. Timeline Gaps & Grain Consistency
- Check whether time series has missing months or irregular intervals.
- Do not compute MoM (Month-over-Month) growth across non-consecutive months without disclosing the gap.
- If data ends mid-month, exclude the partial last period from trend comparisons to prevent false negative signals.
