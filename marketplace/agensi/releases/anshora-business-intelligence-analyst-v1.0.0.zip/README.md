# ANSHora — Business Intelligence Analyst Skill

> **Turn business data into evidence-backed decisions.**

ANSHora is an independent AI business intelligence analyst skill designed for AI agents. It equips your agent with deterministic financial analysis, data quality auditing, root-cause decomposition, and executive decision reporting.

---

## What Buyers Receive

- **`SKILL.md`**: The primary operational directive guiding the AI agent through the 8-stage analysis workflow.
- **`scripts/analyze_csv.py`**: A deterministic Python helper script (standard library only, zero dependencies) for fast, secure, read-only data profiling.
- **`references/`**: Comprehensive guides covering analytical methodology, financial formulas, data quality rules, decision log templates, optional tools, and privacy guardrails.
- **`examples/`**: Synthetic sample business data and a reference analysis report showing the expected standard of output.
- **`requirements.txt`**: Minimal requirements documentation confirming standard library operation.

---

## Key Capabilities

1. **Deterministic Financial Metrics**:
   - Total Revenue, COGS, and Gross Profit.
   - **Weighted Gross Margin**: Strictly calculated as total profit divided by total revenue; never an unweighted row average.
   - Average Order Value (AOV), Return Rate, and Discount Exposure.
2. **Data Trust & Quality Auditing**:
   - 0–100 Data Health Score based on missing values, exact duplicates, and statistical outliers.
   - Exact duplicate row detection and duplicate revenue exposure quantification.
   - Non-destructive processing: never mutates or overwrites source data.
3. **Driver Decomposition (Root-Cause Analysis)**:
   - Price vs. Volume vs. Cost driver decomposition.
   - Segment contribution analysis across product categories, customer segments, and regions.
4. **Scenario Simulation (What-If Analysis)**:
   - Evaluates price, discount, or volume adjustments against historical baselines.
5. **Executive Decision Reports**:
   - Structured 7-section executive reports with designated owners, review dates, and success metrics.

---

## Requirements & Setup

- **Python**: Python 3.10+ (Standard Library only).
- **Supported Formats**: CSV directly (`.csv`, UTF-8, UTF-8 BOM, tab/semicolon/comma delimited).
- **Excel Files (`.xlsx`/`.xls`)**: Processable via native agent spreadsheet tools if available, or by saving the target sheet as a CSV.
- **Zero Cloud Dependencies**: Does not require PostgreSQL, external databases, Google Sign-In, or external API keys.

---

## Privacy & Safety

- **Read-Only**: Analyzes datasets in memory; never modifies source files.
- **No Telemetry**: Contains zero tracking, telemetry, or remote API calls.
- **Local Execution**: Data remains within the buyer's permitted execution boundary.
- **Prompt Injection Defense**: Treats text inside data rows strictly as passive string data.
