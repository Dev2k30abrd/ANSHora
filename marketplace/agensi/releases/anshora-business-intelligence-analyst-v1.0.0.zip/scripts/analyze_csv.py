#!/usr/bin/env python3
"""
ANSHora — Business Intelligence Analyst: Deterministic CSV Analysis Helper.
Pure Python standard library script for inspecting, profiling, and computing
deterministic financial and statistical metrics on CSV datasets.
Zero external dependencies. Read-only. Emits structured JSON to stdout.
"""

import argparse
import csv
import json
import math
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

REVENUE_HINTS = ["revenue", "sales", "total_amount", "order_total", "turnover", "gross_sales", "sale_amount"]
COST_HINTS = ["cost", "cogs", "expenses", "unit_cost", "total_cost", "expense", "purchase_price"]
PROFIT_HINTS = ["profit", "gross_profit", "net_profit", "margin_amount", "operating_profit"]
DISCOUNT_HINTS = ["discount", "discount_amount", "discount_pct", "discount_rate", "coupon_discount"]
RETURN_HINTS = ["return", "returns", "returned", "refund", "refunds", "is_returned", "rto"]
DATE_HINTS = ["date", "order_date", "transaction_date", "invoice_date", "created_at", "timestamp", "day"]
ID_HINTS = ["id", "order_id", "customer_id", "transaction_id", "uuid", "sku", "code", "zip", "postal_code", "phone"]


def clean_number(val):
    if val is None:
        return None
    s = str(val).strip()
    if not s or s.lower() in ("null", "none", "nan", "n/a", "na", "-", ""):
        return None
    cleaned = re.sub(r"[,\s₹$€£%]", "", s)
    try:
        f = float(cleaned)
        return f if math.isfinite(f) else None
    except ValueError:
        return None


def parse_date(val):
    if not val:
        return None
    s = str(val).strip()
    if not s:
        return None
    formats = [
        "%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y",
        "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m", "%b %Y", "%B %Y"
    ]
    for fmt in formats:
        try:
            return datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            continue
    iso_match = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if iso_match:
        try:
            return datetime(int(iso_match.group(1)), int(iso_match.group(2)), int(iso_match.group(3)))
        except ValueError:
            pass
    return None


def detect_delimiter(sample_text):
    if not sample_text:
        return ","
    try:
        return csv.Sniffer().sniff(sample_text[:4096], delimiters=",;\t|").delimiter
    except Exception:
        counts = {d: sample_text.count(d) for d in (",", "\t", ";", "|")}
        best = max(counts, key=counts.get)
        return best if counts[best] > 0 else ","


def calculate_quantiles(sorted_floats):
    n = len(sorted_floats)
    if n == 0:
        return {"min": None, "q1": None, "median": None, "q3": None, "max": None, "iqr": None}
    
    def q(p):
        k = (n - 1) * p
        f = math.floor(k)
        c = math.ceil(k)
        return sorted_floats[int(k)] if f == c else sorted_floats[int(f)] * (c - k) + sorted_floats[int(c)] * (k - f)

    q1, med, q3 = q(0.25), q(0.50), q(0.75)
    iqr = q3 - q1
    return {
        "min": round(sorted_floats[0], 4), "q1": round(q1, 4),
        "median": round(med, 4), "q3": round(q3, 4),
        "max": round(sorted_floats[-1], 4), "iqr": round(iqr, 4),
    }


def find_column_match(headers, hints, explicit_name=None):
    if explicit_name:
        for h in headers:
            if h.strip().lower() == explicit_name.strip().lower():
                return h
        return None
    norm_headers = {re.sub(r"[^a-z0-9]", "", h.lower()): h for h in headers}
    for hint in hints:
        ch = re.sub(r"[^a-z0-9]", "", hint.lower())
        if ch in norm_headers:
            return norm_headers[ch]
    for hint in hints:
        ch = re.sub(r"[^a-z0-9]", "", hint.lower())
        for nh, orig in norm_headers.items():
            if ch in nh:
                return orig
    return None


def analyze(file_path, revenue_col=None, cost_col=None, profit_col=None, date_col=None, dimensions=None, top_n=10):
    path = Path(file_path)
    if not path.exists():
        return {"error": f"File does not exist: {file_path}", "status": "failed"}
    if not path.is_file():
        return {"error": f"Path is not a regular file: {file_path}", "status": "failed"}

    try:
        with open(path, "rb") as bf:
            raw_sample = bf.read(16384)
            if not raw_sample:
                return {
                    "status": "success", "file_name": path.name, "row_count": 0, "column_count": 0,
                    "columns": [], "message": "File is empty (0 bytes).", "data_quality": {"empty": True, "health_score": 0.0}
                }
    except Exception as e:
        return {"error": f"Could not read file: {e}", "status": "failed"}

    has_bom = raw_sample.startswith(b"\xef\xbb\xbf")
    encoding = "utf-8-sig" if has_bom else "utf-8"
    try:
        text_sample = raw_sample.decode(encoding, errors="replace")
    except Exception as e:
        return {"error": f"Encoding error reading file: {e}", "status": "failed"}

    delimiter = detect_delimiter(text_sample)
    rows, seen_hashes = [], set()
    exact_duplicates_count, total_raw_rows = 0, 0

    with open(path, "r", encoding=encoding, errors="replace") as f:
        reader = csv.reader(f, delimiter=delimiter)
        try:
            first_line = next(reader, None)
        except Exception as e:
            return {"error": f"Error parsing CSV header: {e}", "status": "failed"}

        if first_line is None:
            return {
                "status": "success", "file_name": path.name, "row_count": 0, "column_count": 0,
                "columns": [], "message": "File contains no rows.", "data_quality": {"empty": True, "health_score": 0.0}
            }

        headers = [str(h).strip() for h in first_line if str(h).strip()]
        if not headers:
            return {"error": "CSV contains no valid non-empty column headers.", "status": "failed"}
        num_cols = len(headers)

        for raw_row in reader:
            total_raw_rows += 1
            padded = raw_row + [""] * (num_cols - len(raw_row)) if len(raw_row) < num_cols else raw_row[:num_cols]
            row_key = tuple(padded)
            if row_key in seen_hashes:
                exact_duplicates_count += 1
            else:
                seen_hashes.add(row_key)
            rows.append({headers[i]: padded[i].strip() for i in range(num_cols)})

    row_count = len(rows)
    missing_counts, missing_pcts = {}, {}
    numeric_columns, date_columns, categorical_columns = {}, {}, {}

    for h in headers:
        values = [r[h] for r in rows]
        empty_cnt = sum(1 for v in values if not v or v.lower() in ("null", "none", "nan", "n/a", "na", "-"))
        missing_counts[h] = empty_cnt
        missing_pcts[h] = round((empty_cnt / max(row_count, 1)) * 100, 2)

        nums = [clean_number(v) for v in values]
        valid_nums = [n for n in nums if n is not None]
        num_ratio = len(valid_nums) / max(len(values) - empty_cnt, 1)

        dates = [parse_date(v) for v in values]
        valid_dates = [d for d in dates if d is not None]
        date_ratio = len(valid_dates) / max(len(values) - empty_cnt, 1)
        is_id = any(hint in h.lower() for hint in ID_HINTS)

        if date_ratio >= 0.75 and not is_id:
            date_columns[h] = valid_dates
        elif num_ratio >= 0.85 and not is_id:
            numeric_columns[h] = valid_nums
        else:
            categorical_columns[h] = values

    rev_col = find_column_match(headers, REVENUE_HINTS, revenue_col)
    cst_col = find_column_match(headers, COST_HINTS, cost_col)
    prf_col = find_column_match(headers, PROFIT_HINTS, profit_col)
    dt_col = find_column_match(headers, DATE_HINTS, date_col)
    disc_col = find_column_match(headers, DISCOUNT_HINTS)
    ret_col = find_column_match(headers, RETURN_HINTS)

    if prf_col and rev_col and prf_col == rev_col:
        prf_col = None
    if cst_col and rev_col and cst_col == rev_col:
        cst_col = None

    numeric_summaries = {}
    for col_name, nums in numeric_columns.items():
        if not nums:
            continue
        q = calculate_quantiles(sorted(nums))
        iqr = q["iqr"]
        lb = q["q1"] - 1.5 * iqr if iqr is not None else None
        ub = q["q3"] + 1.5 * iqr if iqr is not None else None
        outlier_cnt = sum(1 for n in nums if (lb is not None and (n < lb or n > ub))) if iqr else 0
        numeric_summaries[col_name] = {
            "valid_count": len(nums), "missing_count": missing_counts[col_name],
            "sum": round(sum(nums), 4), "mean": round(sum(nums) / len(nums), 4),
            "quantiles": q, "outliers_count": outlier_cnt,
            "outlier_bounds": {"lower": round(lb, 4) if lb else None, "upper": round(ub, 4) if ub else None}
        }

    financial_kpis = {
        "revenue_column": rev_col, "cost_column": cst_col, "profit_column": prf_col,
        "date_column": dt_col, "discount_column": disc_col, "return_column": ret_col,
        "total_revenue": None, "total_cost": None, "total_profit": None,
        "weighted_margin_pct": None, "cost_source": None, "profit_source": None,
        "zero_revenue_rows": 0, "negative_revenue_rows": 0,
    }

    if rev_col and rev_col in numeric_columns:
        rev_nums = numeric_columns[rev_col]
        total_rev = sum(rev_nums)
        financial_kpis["total_revenue"] = round(total_rev, 2)
        financial_kpis["average_order_value"] = round(total_rev / max(len(rev_nums), 1), 2)
        financial_kpis["zero_revenue_rows"] = sum(1 for v in rev_nums if v == 0)
        financial_kpis["negative_revenue_rows"] = sum(1 for v in rev_nums if v < 0)

        has_p = prf_col and prf_col in numeric_columns
        has_c = cst_col and cst_col in numeric_columns
        paired_rev, paired_profit, paired_cost = [], [], []

        for r in rows:
            rv = clean_number(r.get(rev_col))
            pv = clean_number(r.get(prf_col)) if has_p else None
            cv = clean_number(r.get(cst_col)) if has_c else None
            if has_p and rv is not None and pv is not None:
                paired_rev.append(rv)
                paired_profit.append(pv)
                paired_cost.append(rv - pv)
            elif has_c and rv is not None and cv is not None:
                paired_rev.append(rv)
                paired_cost.append(cv)
                paired_profit.append(rv - cv)

        if has_p and paired_profit:
            tot_p, tot_pr_rev = sum(paired_profit), sum(paired_rev)
            financial_kpis["total_profit"] = round(tot_p, 2)
            financial_kpis["profit_source"] = f"direct from column '{prf_col}'"
            if tot_pr_rev > 0:
                financial_kpis["weighted_margin_pct"] = round((tot_p / tot_pr_rev) * 100, 2)
            if not has_c:
                financial_kpis["total_cost"] = round(tot_pr_rev - tot_p, 2)
                financial_kpis["cost_source"] = "derived (revenue - profit)"
            else:
                financial_kpis["total_cost"] = round(sum(numeric_columns[cst_col]), 2)
                financial_kpis["cost_source"] = f"direct from column '{cst_col}'"
        elif has_c and paired_cost:
            tot_c, tot_pr_rev = sum(paired_cost), sum(paired_rev)
            derived_p = tot_pr_rev - tot_c
            financial_kpis["total_cost"] = round(tot_c, 2)
            financial_kpis["total_profit"] = round(derived_p, 2)
            financial_kpis["cost_source"] = f"direct from column '{cst_col}'"
            financial_kpis["profit_source"] = "derived (revenue - cost)"
            if tot_pr_rev > 0:
                financial_kpis["weighted_margin_pct"] = round((derived_p / tot_pr_rev) * 100, 2)

    target_dims = []
    if dimensions:
        for d in dimensions:
            for h in headers:
                if h.strip().lower() == d.strip().lower():
                    target_dims.append(h)
    else:
        for h, vals in categorical_columns.items():
            dcnt = len(set(v for v in vals if v))
            if 2 <= dcnt <= 25 and not any(id_w in h.lower() for id_w in ID_HINTS):
                target_dims.append(h)
                if len(target_dims) >= 3:
                    break

    segment_breakdowns = {}
    total_valid_rev = financial_kpis["total_revenue"] or 1.0
    for dim in target_dims:
        counts = Counter(r[dim] for r in rows if r[dim])
        dim_data = []
        for cat in [c for c, _ in counts.most_common(top_n)]:
            cat_rows = [r for r in rows if r[dim] == cat]
            cnt = len(cat_rows)
            cat_rev = sum(clean_number(r[rev_col]) or 0 for r in cat_rows) if rev_col else 0
            item = {
                "segment_value": cat, "row_count": cnt,
                "row_share_pct": round((cnt / max(row_count, 1)) * 100, 2),
            }
            if rev_col:
                item["revenue"] = round(cat_rev, 2)
                item["revenue_share_pct"] = round((cat_rev / max(total_valid_rev, 1e-9)) * 100, 2)
            if prf_col:
                cat_p = sum(clean_number(r[prf_col]) or 0 for r in cat_rows)
                item["profit"] = round(cat_p, 2)
                if cat_rev > 0:
                    item["margin_pct"] = round((cat_p / cat_rev) * 100, 2)
            elif cst_col and rev_col:
                cat_c = sum(clean_number(r[cst_col]) or 0 for r in cat_rows)
                cat_p = cat_rev - cat_c
                item["cost"] = round(cat_c, 2)
                item["profit"] = round(cat_p, 2)
                if cat_rev > 0:
                    item["margin_pct"] = round((cat_p / cat_rev) * 100, 2)
            dim_data.append(item)
        segment_breakdowns[dim] = dim_data

    time_series = []
    if dt_col:
        period_groups = defaultdict(list)
        for r in rows:
            dt_obj = parse_date(r.get(dt_col))
            if dt_obj:
                period_groups[dt_obj.strftime("%Y-%m")].append(r)
        prev_rev = None
        for p in sorted(period_groups.keys()):
            p_rows = period_groups[p]
            p_rev = sum(clean_number(r[rev_col]) or 0 for r in p_rows) if rev_col else None
            p_growth = round(((p_rev - prev_rev) / prev_rev) * 100, 2) if (prev_rev and prev_rev > 0 and p_rev is not None) else None
            entry = {"period": p, "rows": len(p_rows)}
            if p_rev is not None:
                entry["revenue"] = round(p_rev, 2)
                entry["growth_vs_previous_period_pct"] = p_growth
            if prf_col:
                p_prf = sum(clean_number(r[prf_col]) or 0 for r in p_rows)
                entry["profit"] = round(p_prf, 2)
                if p_rev and p_rev > 0:
                    entry["margin_pct"] = round((p_prf / p_rev) * 100, 2)
            elif cst_col and rev_col:
                p_cst = sum(clean_number(r[cst_col]) or 0 for r in p_rows)
                p_prf = p_rev - p_cst
                entry["cost"] = round(p_cst, 2)
                entry["profit"] = round(p_prf, 2)
                if p_rev and p_rev > 0:
                    entry["margin_pct"] = round((p_prf / p_rev) * 100, 2)
            time_series.append(entry)
            if p_rev is not None:
                prev_rev = p_rev

    avg_missing = sum(missing_pcts.values()) / max(len(missing_pcts), 1)
    dup_pct = (exact_duplicates_count / max(row_count, 1)) * 100
    total_outliers = sum(s["outliers_count"] for s in numeric_summaries.values())
    outlier_pct = (total_outliers / max(row_count * max(len(numeric_summaries), 1), 1)) * 100
    quality_score = max(0.0, min(100.0, round(100.0 - (avg_missing * 1.5) - (dup_pct * 2.0) - (outlier_pct * 1.0), 1)))

    return {
        "status": "success", "file_name": path.name, "delimiter": delimiter,
        "has_utf8_bom": has_bom, "row_count": row_count, "total_raw_rows": total_raw_rows,
        "column_count": num_cols, "columns": headers,
        "data_quality": {
            "health_score": quality_score, "exact_duplicate_rows": exact_duplicates_count,
            "duplicate_percentage": round(dup_pct, 2), "missing_values_by_column": missing_counts,
            "missing_percentages": missing_pcts, "total_outliers_detected": total_outliers,
        },
        "capabilities": {
            "revenue_available": rev_col is not None,
            "cost_available": bool(cst_col or (rev_col and prf_col)),
            "profit_available": bool(prf_col or (rev_col and cst_col)),
            "date_timeline_available": bool(dt_col and len(time_series) >= 2),
            "discount_available": disc_col is not None,
            "returns_available": ret_col is not None,
            "customer_segments_available": len(segment_breakdowns) > 0,
        },
        "financial_kpis": financial_kpis, "numeric_summaries": numeric_summaries,
        "segment_breakdowns": segment_breakdowns, "time_series": time_series,
        "analytical_notices": [
            f"Dataset contains {row_count:,} rows and {num_cols} columns.",
            "Overall weighted margin = (Total Profit ÷ Total Revenue × 100); row margins are never averaged.",
            f"Exact duplicate rows ({exact_duplicates_count}) are identified for audit transparency and not silently removed.",
        ]
    }


def main():
    p = argparse.ArgumentParser(description="Deterministic CSV Business Intelligence Analysis Helper")
    p.add_argument("file_path", help="Path to input CSV")
    p.add_argument("--revenue", dest="revenue_col", default=None)
    p.add_argument("--cost", dest="cost_col", default=None)
    p.add_argument("--profit", dest="profit_col", default=None)
    p.add_argument("--date", dest="date_col", default=None)
    p.add_argument("--dimensions", dest="dimensions", default=None)
    p.add_argument("--top", dest="top_n", type=int, default=10)

    args = p.parse_args()
    dims = [d.strip() for d in args.dimensions.split(",")] if args.dimensions else None
    res = analyze(args.file_path, args.revenue_col, args.cost_col, args.profit_col, args.date_col, dims, args.top_n)
    sys.stdout.write(json.dumps(res, indent=2) + "\n")
    if res.get("status") == "failed":
        sys.exit(1)


if __name__ == "__main__":
    main()
